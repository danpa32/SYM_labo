package ch.heigvd.iict.sym.wearcommon;

/**
 * Project: Labo4
 * Created by fabien.dutoit on 21.12.2016
 * (C) 2016 - HEIG-VD, IICT
 */

public class Constants {

    public static final String MY_PENDING_INTENT_ACTION = "ch.heigvd.iict.sym.sym_labo4/MY_MESSAGE";

    // MAY BE USED TO STORE CONSTANTS SHARED BY THE 2 APPLICATIONS
}
